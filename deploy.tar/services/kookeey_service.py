"""kookeey 代理服务集成（v2.9.0）。

支持两种模式：
1. 提取链接模式：用户在设置页填 kookeey 提取链接（含 sign + accessid 的完整 URL），
   后端调链接拉 IP 列表入池。最省事，用户已有现成链接。
2. API 签名模式：用户填 developer_token（加密密钥）+ access_id（developer id），
   后端用 HMAC-SHA1 签名调 kookeey 官方 API 查询流量/账户/明细。

流量统计：kookeey API 不提供单 IP 流量，按请求次数 × 估算大小统计（或调 /ol 订单列表接口拿总量）。
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import re
import time
from dataclasses import dataclass, field
from threading import Lock
from typing import Any
from urllib.parse import quote

from curl_cffi.requests import Session

from services.config import _mask_token
from services.log_service import LOG_TYPE_ACCOUNT, log_service
from services.proxy_pool import proxy_pool

# kookeey 官方开发者 API（实测：API 主机是 www.kkoip.com，非文档写的 kookeey.com——
# kookeey.com 是营销站/前端；且服务器（阿里云/腾讯云海外）直连被墙，须走 kookeey
# 住宅代理出口访问）。t=2 动态住宅；签名 HMAC-SHA1(token)+base64（与文档示例逐字对齐）。
KOOKEEY_API_BASE = "https://www.kkoip.com"


def _sign(params: list[tuple[str, str]], token: str) -> str:
    """kookeey 签名：参数串（按 URL 顺序）HMAC-SHA1(token) → hex → base64。

    文档口径：base64.b64encode(hmac.new(key, param_string, sha1).hexdigest().encode())
    """
    param_string = "&".join(f"{k}={v}" for k, v in params)
    digest = hmac.new(token.encode("utf-8"), param_string.encode("utf-8"), hashlib.sha1).hexdigest()
    return base64.b64encode(digest.encode("utf-8")).decode("utf-8")


def _api_get(
    method: str,
    params: list[tuple[str, str]],
    access_id: str,
    token: str,
    timeout: int = 30,
    proxy: str = "",
    verify: bool = False,
) -> dict:
    """调 kookeey 官方 API：GET /[method]?accessid=..&signature=..&ts=..&{params}。

    签名串只含业务参数 + ts（不含 accessid/signature），顺序与 URL 一致。
    proxy：kookeey.com 在海外服务器直连被墙，调用方传住宅代理出口（同账号粘性或共享）。
    verify：SSL 证书校验开关，默认 False（kookeey 住宅代理出口可能做 MITM 截获 HTTPS）。
    返回 data（dict/list）；success!=True 抛错。
    """
    ts = str(int(time.time()))
    # 业务参数 + ts 一起签名（顺序：业务参数在前，ts 最后，与文档示例一致）
    sign_params = [*params, ("ts", ts)]
    signature = _sign(sign_params, token)
    query = [("accessid", access_id), ("signature", signature), *params, ("ts", ts)]
    qs = "&".join(f"{k}={quote(str(v), safe='')}" for k, v in query)
    url = f"{KOOKEEY_API_BASE}/{method.lstrip('/')}?{qs}"
    proxies = {"http": proxy, "https": proxy} if proxy else None
    with Session(impersonate="chrome110",
                 verify=verify,
                 proxies=proxies) as session:
        resp = session.get(url, timeout=timeout)
        body = resp.json() if resp.text else {}
    if not isinstance(body, dict):
        raise RuntimeError(f"kookeey api bad response: {str(body)[:120]}")
    if body.get("success") is not True:
        raise RuntimeError(f"kookeey api error code={body.get('code')} msg={body.get('msg')}")
    return body.get("data") if isinstance(body.get("data"), (dict, list)) else {}



@dataclass
class KookeeyConfig:
    enabled: bool = False
    extract_url: str = ""  # 提取链接模式：完整 URL（含 sign + accessid）
    developer_token: str = ""  # API 签名模式：开发者 token（base64）
    access_id: str = ""  # API 签名模式：accessid
    default_country: str = "US"
    default_count: int = 10
    ssl_verify: bool = False  # SSL 证书校验：kookeey 住宅代理作为中间人截获 HTTPS 流量
    #                                   （MITM），导致标准证书链验证失败，默认关闭校验。
    #                                   若用户自建代理隧道（无 MITM），可开启以防护中间人攻击。
    proxy_enabled: bool = False  # 是否启用 kookeey 动态住宅代理作为请求出口。
    #                             仅用于密码重新登录/OTP 取件等账号管理操作。
    #                             默认关闭：API 生图/对话请求走服务器直连或 proxy_runtime 配置，
    #                             不走 kookeey 动态 IP（kookeey 流量按量计费，仅推荐用于批量注册场景）。


@dataclass
class KookeeyStats:
    """kookeey 用量统计（累计，重启不丢）。"""
    total_extracted: int = 0  # 累计拉取 IP 数
    total_requests: int = 0  # 累计调 kookeey 次数
    total_errors: int = 0
    last_extract_at: str = ""
    last_extract_count: int = 0
    last_error: str = ""
    # 按国家统计
    by_country: dict[str, int] = field(default_factory=dict)


@dataclass
class IpUsageRecord:
    """单账号（一条粘性住宅 IP）的使用画像。"""
    email: str
    session: str  # kookeey 粘性 session（md5(email)[:8]）
    requests: int = 0  # 成功调用次数（≈ 该 IP 请求数）
    fail: int = 0
    request_bytes: int = 0  # 累计请求字节数（估算，kookeey API 不提供单 IP 真实流量）
    last_used_at: str = ""
    last_ip: str = ""  # 最近一次批量探测到的出口 IP
    last_probe_at: str = ""


class KookeeyService:
    """kookeey 代理集成服务。"""

    def __init__(self) -> None:
        self._config = KookeeyConfig()
        self._stats = KookeeyStats()
        self._lock = Lock()
        # 单 IP（按账号 session）使用画像：email → IpUsageRecord
        self._ip_usage: dict[str, IpUsageRecord] = {}

    # ------------------------------------------------------------ 单 IP 使用画像（按账号 session）
    @staticmethod
    def _session_for(email: str) -> str:
        return hashlib.md5(str(email or "").strip().lower().encode("utf-8")).hexdigest()[:8]

    def record_ip_usage(self, email: str, success: bool, bytes: int | None = None) -> None:
        """记录一次账号调用（≈ 该账号粘性 IP 的一次请求）。供账号用量挂钩调用。

        bytes：本次请求估算字节数（图片从 upstream Content-Length 取，文本用固定值估算）。
        kookeey 官方 API 不提供单 IP 级别流量，此值为估算，精确值待 kookeey 支持。
        """
        email = str(email or "").strip()
        if not email:
            return
        with self._lock:
            rec = self._ip_usage.get(email)
            if rec is None:
                rec = IpUsageRecord(email=email, session=self._session_for(email))
                self._ip_usage[email] = rec
            if success:
                rec.requests += 1
            else:
                rec.fail += 1
            if bytes is not None and bytes > 0:
                rec.request_bytes += bytes
            rec.last_used_at = time.strftime("%Y-%m-%d %H:%M:%S")

    def update_ip_probe(self, email: str, ip: str) -> None:
        """批量探测后回填该账号 session 对应的出口 IP。"""
        email = str(email or "").strip()
        if not email:
            return
        with self._lock:
            rec = self._ip_usage.get(email)
            if rec is None:
                rec = IpUsageRecord(email=email, session=self._session_for(email))
                self._ip_usage[email] = rec
            rec.last_ip = ip
            rec.last_probe_at = time.strftime("%Y-%m-%d %H:%M:%S")

    def get_ip_usage_board(self) -> dict:
        """单 IP 使用画像看板：按请求数排行 + 累计取出/使用统计 + 流量估算。

        「已使用 IP 数」= 有过至少一次调用记录的 session 数。
        「累计取出 IP 数」= stats.total_extracted（提取入池的 IP 总数）。
        total_bytes / estimated_mb：所有账号累计估算流量（kookeey API 不提供单 IP 真实流量）。
        """
        with self._lock:
            rows = [
                {
                    "email": r.email,
                    "session": r.session,
                    "requests": r.requests,
                    "fail": r.fail,
                    "total_bytes": r.request_bytes,
                    "estimated_mb": round(r.request_bytes / (1024 * 1024), 3) if r.request_bytes else 0.0,
                    "last_used_at": r.last_used_at,
                    "last_ip": r.last_ip,
                    "last_probe_at": r.last_probe_at,
                }
                for r in self._ip_usage.values()
            ]
            total_bytes = sum(r.request_bytes for r in self._ip_usage.values())
            extracted = self._stats.total_extracted
        rows.sort(key=lambda x: x["requests"], reverse=True)
        return {
            "used_ip_count": len(rows),
            "total_extracted": extracted,
            "total_bytes": total_bytes,
            "estimated_mb": round(total_bytes / (1024 * 1024), 3) if total_bytes else 0.0,
            "leaderboard": rows,  # 已按 requests 降序 = 每 IP 使用排行
        }

    # ------------------------------------------------------------ 批量出口 IP 探测（定时/手动）
    def probe_all_account_ips(self, max_workers: int = 8, only_status: tuple[str, ...] = ("正常",)) -> dict:
        """批量探测所有正常账号经各自粘性住宅代理的出口 IP，回填 last_ip。

        并发探测，单号失败不阻断整体。返回 {probed, ok, failed, duration_s}。
        """
        from concurrent.futures import ThreadPoolExecutor, as_completed

        from services.account_service import account_service
        from services.proxy_service import kookeey_proxy_for

        emails = []
        for acc in account_service.list_accounts() or []:
            if not isinstance(acc, dict):
                continue
            if only_status and str(acc.get("status") or "") not in only_status:
                continue
            email = str(acc.get("email") or "").strip()
            if email:
                emails.append(email)
        if not emails:
            return {"probed": 0, "ok": 0, "failed": 0, "duration_s": 0}

        start = time.time()
        ok = 0
        failed = 0
        ssl_verify = self._ssl_verify()

        def _probe(email: str) -> bool:
            proxy_url = kookeey_proxy_for(email)
            if not proxy_url:
                return False
            try:
                with Session(impersonate="chrome110",
                             verify=ssl_verify,
                             proxies={"http": proxy_url, "https": proxy_url}) as s:
                    resp = s.get("https://api.ipify.org?format=json", timeout=20)
                    ip = str((resp.json() or {}).get("ip") or "")
                if ip:
                    self.update_ip_probe(email, ip)
                    return True
            except Exception:
                return False
            return False

        with ThreadPoolExecutor(max_workers=max(1, max_workers)) as ex:
            futs = {ex.submit(_probe, e): e for e in emails}
            for fut in as_completed(futs):
                try:
                    if fut.result():
                        ok += 1
                    else:
                        failed += 1
                except Exception:
                    failed += 1
        duration = round(time.time() - start, 1)
        log_service.add(LOG_TYPE_ACCOUNT, "kookeey 批量出口IP探测", {"probed": len(emails), "ok": ok, "failed": failed})
        return {"probed": len(emails), "ok": ok, "failed": failed, "duration_s": duration}
    def _ssl_verify(self) -> bool:
        """返回当前 SSL 证书校验开关值（默认 False，kookeey 住宅代理可能 MITM）。"""
        with self._lock:
            return self._config.ssl_verify

    def update_config(self, cfg: dict) -> None:
        with self._lock:
            self._config.enabled = bool(cfg.get("enabled", False))
            self._config.extract_url = str(cfg.get("extract_url") or "").strip()
            raw_token = str(cfg.get("developer_token") or "").strip()
            if raw_token and raw_token.startswith("****"):
                # 前端 GET 返回的是脱敏 token（get_public_config），不覆盖真实值
                pass
            else:
                self._config.developer_token = raw_token
            self._config.access_id = str(cfg.get("access_id") or "").strip()
            self._config.default_country = str(cfg.get("default_country") or "US").strip() or "US"
            try:
                self._config.default_count = max(1, min(100, int(cfg.get("default_count") or 10)))
            except (TypeError, ValueError):
                self._config.default_count = 10
            self._config.ssl_verify = bool(cfg.get("ssl_verify", False))
            self._config.proxy_enabled = bool(cfg.get("proxy_enabled", False))

    def get_config(self) -> dict:
        with self._lock:
            return {
                "enabled": self._config.enabled,
                "extract_url": self._config.extract_url,
                "developer_token": self._config.developer_token,
                "access_id": self._config.access_id,
                "default_country": self._config.default_country,
                "default_count": self._config.default_count,
                "ssl_verify": self._config.ssl_verify,
                "proxy_enabled": self._config.proxy_enabled,
            }

    def get_public_config(self) -> dict:
        """返回给前端/API 的配置（developer_token 脱敏）。"""
        cfg = self.get_config()
        raw = cfg["developer_token"]
        if raw:
            cfg["developer_token"] = _mask_token(raw) if len(raw) > 4 else "****"
        return cfg

    def get_stats(self) -> dict:
        with self._lock:
            return {
                "total_extracted": self._stats.total_extracted,
                "total_requests": self._stats.total_requests,
                "total_errors": self._stats.total_errors,
                "last_extract_at": self._stats.last_extract_at,
                "last_extract_count": self._stats.last_extract_count,
                "last_error": self._stats.last_error,
                "by_country": dict(self._stats.by_country),
            }

    # ------------------------------------------------------------ 官方开发者 API（流量/账户）
    def _api_creds(self) -> tuple[str, str]:
        """返回 (access_id, developer_token)；未配置返回 ('','')。"""
        with self._lock:
            return self._config.access_id, self._config.developer_token

    def _api_proxy(self) -> str:
        """kookeey API 出口代理：API 主机在海外服务器直连被墙，须走 kookeey 住宅代理。

        用一个固定共享 session（非按账号）的住宅出口访问 API 即可。
        """
        try:
            from services.proxy_service import kookeey_proxy_for
            return kookeey_proxy_for("kookeey-api@internal") or ""
        except Exception:
            return ""

    def get_traffic_overview(self) -> dict:
        """流量总览卡片数据：调 /tinfo（剩余/今日/近30天）+ /package（动态住宅包余额）。

        返回 {ok, balance_mb, today_use_mb, month_use_mb, package:{traffic_left_gb,
        traffic_total_gb, thread_left, thread_total, expire_time}, error}。
        未配置 developer_token/access_id 返回 ok=False + need_config。
        """
        access_id, token = self._api_creds()
        if not (access_id and token):
            return {"ok": False, "need_config": True, "error": "未配置 developer_token / access_id"}
        proxy = self._api_proxy()
        verify = self._ssl_verify()
        try:
            tinfo = _api_get("tinfo", [], access_id, token, proxy=proxy, verify=verify)
        except Exception as exc:
            return {"ok": False, "error": f"tinfo: {exc}"}
        result: dict[str, Any] = {
            "ok": True,
            "balance_mb": tinfo.get("balance") if isinstance(tinfo, dict) else None,
            "today_use_mb": tinfo.get("today_use") if isinstance(tinfo, dict) else None,
            "month_use_mb": tinfo.get("month_use") if isinstance(tinfo, dict) else None,
        }
        # /package?t=2 动态住宅包余额（失败不阻断总览）
        try:
            pkg = _api_get("package", [("t", "2")], access_id, token, proxy=proxy, verify=verify)
            if isinstance(pkg, dict):
                result["package"] = {
                    "traffic_left_gb": pkg.get("traffic_left"),
                    "traffic_total_gb": pkg.get("traffic_total"),
                    "thread_left": pkg.get("thread_left"),
                    "thread_total": pkg.get("thread_total"),
                    "expire_time": pkg.get("expire_time"),
                    "name": (pkg.get("package") or {}).get("name") if isinstance(pkg.get("package"), dict) else None,
                }
        except Exception as exc:
            result["package_error"] = str(exc)[:120]
        return result

    def get_account_balance(self) -> dict:
        """账户余额（/info）：{balance_cents, uncount_cents}。未配置返回 need_config。"""
        access_id, token = self._api_creds()
        if not (access_id and token):
            return {"ok": False, "need_config": True, "error": "未配置 developer_token / access_id"}
        try:
            data = _api_get("info", [("u", access_id)], access_id, token, proxy=self._api_proxy(), verify=self._ssl_verify())
            return {
                "ok": True,
                "balance_cents": data.get("balance") if isinstance(data, dict) else None,
                "uncount_cents": data.get("uncount") if isinstance(data, dict) else None,
            }
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def get_traffic_detail(self, sdate: str, edate: str, gb: str = "d", page: int = 1, psize: int = 50) -> dict:
        """流量使用明细（/tdetail）：按天/小时聚合，含地区/账号。返回 {ok, list, total}。"""
        access_id, token = self._api_creds()
        if not (access_id and token):
            return {"ok": False, "need_config": True, "error": "未配置 developer_token / access_id"}
        params = [("sdate", sdate), ("edate", edate), ("gb", gb), ("page", str(page)), ("psize", str(psize))]
        try:
            data = _api_get("tdetail", params, access_id, token, proxy=self._api_proxy(), verify=self._ssl_verify())
            if isinstance(data, dict):
                return {"ok": True, "list": data.get("list") or [], "total": data.get("total"), "raw": data}
            return {"ok": True, "list": [], "total": 0}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def test_connection(self) -> dict:
        """测试 kookeey 连接：用提取链接拉 1 个 IP 验证可用。"""
        with self._lock:
            url = self._config.extract_url
            enabled = self._config.enabled
        if not enabled or not url:
            return {"ok": False, "error": "kookeey 未启用或提取链接为空"}
        try:
            # 调链接拉 IP（n=1 测试）
            test_url = self._build_extract_url(count=1)
            ips = self._fetch_ips(test_url)
            return {"ok": True, "extracted": len(ips), "sample": ips[0] if ips else ""}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def extract_to_pool(self, country: str = "", count: int = 0) -> dict:
        """从 kookeey 拉 IP 入池。返回 {extracted, imported, deduped, skipped}。"""
        with self._lock:
            if not self._config.enabled:
                return {"ok": False, "error": "kookeey 未启用"}
            url = self._config.extract_url
            if not url:
                return {"ok": False, "error": "提取链接为空"}
            country = country or self._config.default_country
            count = max(1, min(100, count or self._config.default_count))

        try:
            extract_url = self._build_extract_url(country=country, count=count)
            self._record_request()
            ips = self._fetch_ips(extract_url)
            # 解析每行 IP 入池
            imported = 0
            deduped = 0
            skipped = 0
            for line in ips:
                parsed = _parse_kookeey_ip_line(line, country=country)
                if parsed is None:
                    skipped += 1
                    continue
                if proxy_pool.add_structured(parsed, weight=1):
                    imported += 1
                else:
                    deduped += 1
            self._record_extract_success(len(ips), imported, country)
            log_service.add(
                LOG_TYPE_ACCOUNT,
                "kookeey 提取 IP 入池",
                {"country": country, "count": count, "extracted": len(ips),
                 "imported": imported, "deduped": deduped, "skipped": skipped},
            )
            return {
                "ok": True,
                "extracted": len(ips),
                "imported": imported,
                "deduped": deduped,
                "skipped": skipped,
                "country": country,
            }
        except Exception as exc:
            self._record_error(str(exc))
            log_service.add(LOG_TYPE_ACCOUNT, "kookeey 提取失败", {"error": str(exc)[:200]})
            return {"ok": False, "error": str(exc)}

    def _build_extract_url(self, country: str = "", count: int = 10) -> str:
        """构建提取链接：基于用户配置的 extract_url，替换 n 和 g 参数。"""
        with self._lock:
            base = self._config.extract_url
        # 简单替换 n 和 g 参数
        url = re.sub(r"([?&])n=\d+", rf"\1n={count}", base)
        if country:
            if re.search(r"[?&]g=", url):
                url = re.sub(r"([?&]g=)[^&]*", rf"\1{country}", url)
            else:
                url += f"&g={country}"
        return url

    def _fetch_ips(self, url: str) -> list[str]:
        """调 kookeey 提取链接，返回 IP 行列表。"""
        with Session(impersonate="chrome110", verify=True) as session:
            resp = session.get(url, timeout=30)
            if resp.status_code != 200:
                raise RuntimeError(f"kookeey extract http_{resp.status_code}: {resp.text[:200]}")
            text = resp.text or ""
            lines = [line.strip() for line in text.splitlines() if line.strip()]
            return lines

    def _record_request(self) -> None:
        with self._lock:
            self._stats.total_requests += 1

    def _record_extract_success(self, extracted: int, imported: int, country: str) -> None:
        with self._lock:
            self._stats.total_extracted += extracted
            self._stats.last_extract_at = time.strftime("%Y-%m-%d %H:%M:%S")
            self._stats.last_extract_count = extracted
            self._stats.by_country[country] = self._stats.by_country.get(country, 0) + imported

    def _record_error(self, error: str) -> None:
        with self._lock:
            self._stats.total_errors += 1
            self._stats.last_error = error[:200]

    @staticmethod
    def start_ip_probe_watcher(stop_event, interval_seconds: int = 7200) -> Thread:
        """定时批量探测所有账号出口 IP（默认每 2 小时一轮），常驻刷新看板显示。

        返回线程对象；interval_seconds 可用环境变量 KOOKEEY_IP_PROBE_INTERVAL_SEC 覆盖。
        """
        import os
        from threading import Thread

        try:
            interval_seconds = max(600, int(os.getenv("KOOKEEY_IP_PROBE_INTERVAL_SEC", str(interval_seconds))))
        except (TypeError, ValueError):
            interval_seconds = 7200

        def worker() -> None:
            # 启动后先等一小段再首探（让服务先起来），之后按间隔循环
            if stop_event.wait(60):
                return
            while not stop_event.is_set():
                try:
                    cfg = kookeey_service.get_config()
                    if cfg.get("enabled"):
                        kookeey_service.probe_all_account_ips()
                except Exception as exc:  # noqa: BLE001
                    log_service.add(LOG_TYPE_ACCOUNT, "kookeey IP探测线程异常", {"error": str(exc)[:120]})
                if stop_event.wait(interval_seconds):
                    return

        t = Thread(target=worker, name="kookeey-ip-probe", daemon=True)
        t.start()
        return t

def _parse_kookeey_ip_line(line: str, country: str = "") -> dict | None:
    """解析 kookeey 提取返回的单行 IP。

    kookeey 提取链接返回格式可能是：
    - gate.kookeey.info:1000:1023701-4a2c845a:12843fee-US  （带国家后缀）
    - 1.2.3.4:7135  （纯 IP:port，白名单模式）
    - ip:user:pass@host:port
    """
    from services.proxy_pool import parse_proxy_line
    parsed = parse_proxy_line(line)
    if parsed is None:
        return None
    parsed["source"] = "kookeey"
    if country and not parsed.get("country"):
        parsed["country"] = country
    return parsed


# 全局单例
kookeey_service = KookeeyService()
