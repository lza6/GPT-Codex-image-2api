"""请求级上下文：中间件注入，审计/日志读取。

与 metrics_service 的 request_id contextvar 同模式，但独立存放 path/method/ip，
供 require_admin 等无 Request 参数的函数在埋点时读取，避免为审计改 90 处端点签名。
"""

from __future__ import annotations

import contextvars
from typing import Any

_request_ctx: contextvars.ContextVar[dict[str, Any]] = contextvars.ContextVar(
    "chatgpt2api_request_context", default={}
)


def set_request_context(*, path: str, method: str, ip: str) -> None:
    """中间件设置当前请求上下文（每次请求开始调用）。"""
    _request_ctx.set({"path": path, "method": method, "ip": ip})


def get_request_path() -> str:
    return str(_request_ctx.get().get("path") or "")


def get_request_method() -> str:
    return str(_request_ctx.get().get("method") or "")


def get_request_ip() -> str:
    return str(_request_ctx.get().get("ip") or "")
