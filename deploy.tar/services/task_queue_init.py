"""任务队列处理器注册。在 app 启动时调用。"""
from __future__ import annotations

import logging
from typing import Any

from services.task_queue import Task, TaskPriority, task_queue

logger = logging.getLogger(__name__)


def register_task_handlers() -> None:
    """注册所有任务处理器并启动消费者。"""

    # 图片生成/编辑任务（CRITICAL）
    task_queue.register_handler("image_generation", _handle_image_task)
    task_queue.register_handler("image_edit", _handle_image_task)

    # 图片续轮询（CRITICAL）
    task_queue.register_handler("image_resume_poll", _handle_image_resume_poll)

    # 备份任务（LOW）
    task_queue.register_handler("backup", _handle_backup)

    # 日志清理任务（LOW）
    task_queue.register_handler("log_cleanup", _handle_log_cleanup)

    task_queue.start_consumer()
    logger.info("task queue handlers registered, consumer started")


def _handle_image_task(task: Task) -> Any:
    """图片任务处理器：委托给 image_task_service._run_task。"""
    from services.image_task_service import image_task_service

    image_task_service._run_task(
        task.metadata["key"],
        task.metadata["mode"],
        task.metadata["payload"],
        task.metadata["identity"],
        task.metadata["model"],
    )
    return None


def _handle_image_resume_poll(task: Task) -> Any:
    """图片续轮询任务处理器。"""
    from services.image_task_service import image_task_service

    image_task_service._run_resume_poll(
        task.metadata["key"],
        task.metadata["conversation_id"],
        task.metadata.get("extra_timeout_secs", 30.0),
        task.metadata["identity"],
        task.metadata.get("mode", "generate"),
        task.metadata.get("model", "gpt-image-2"),
    )
    return None


def _handle_backup(task: Task) -> dict[str, object]:
    """备份任务处理器：执行备份，自动重新调度下一个备份检查。"""
    from services.backup_service import backup_service

    try:
        result = backup_service.run_backup(trigger="task_queue")
        return result
    finally:
        # 无论成败，继续调度下一次备份检查（30s 后）
        import threading
        threading.Thread(
            target=_schedule_next_backup_check,
            daemon=True,
            name="backup-reschedule",
        ).start()


def _schedule_next_backup_check() -> None:
    """30s 后重新提交备份检查任务。"""
    import time
    time.sleep(30)
    from services.backup_service import backup_service

    settings = backup_service.get_settings()
    if settings.get("enabled"):
        task_queue.enqueue("backup", priority=TaskPriority.LOW, metadata={"trigger": "schedule"})


def _handle_log_cleanup(task: Task) -> None:
    """日志清理处理器。"""
    from services.log_service import log_service
    log_service._auto_cleanup()